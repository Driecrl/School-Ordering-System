# QCU Canteen Ordering System

Plain HTML, CSS, and JavaScript frontend with a Node.js/Express API and MariaDB storage. XAMPP starts the local MariaDB service; HeidiSQL can create and inspect the database. The MariaDB Node.js connector links the app to the database.

## What it includes

- Student sign-in with student number and PIN; staff sign-in with staff ID and PIN.
- One-time temporary PINs, required PIN change on first sign-in, and an account provisioning/reset command.
- Argon2id PIN hashes, server-side attempt limits, expiring temporary PINs, and MariaDB-backed sessions.
- Student-only order history and staff-only order status controls.
- Cash-at-pickup ordering. Online payments and delivery are not included.

The server contains no real student accounts. Create accounts from an approved roster using the provisioning command below.

## Local setup with XAMPP

Requirements: Node.js 22.14 or newer, pnpm or npm, and XAMPP for Windows.

1. Open the XAMPP Control Panel and start **MySQL**. XAMPP labels this service “MySQL”; its included server is MariaDB.
2. Copy `.env.example` to `.env`. Set the MariaDB host, port, user, and password to match your XAMPP configuration. For a local-only XAMPP setup, the usual host and port are `127.0.0.1` and `3306`; use the actual account password configured on your machine.
3. Set separate random values of at least 32 characters for `SESSION_SECRET` and `PIN_PEPPER`. Keep `.env` private.
4. Install dependencies: `pnpm install` (or `npm install`).
5. Create the `qcu_canteen` database, tables, and sample menu: `pnpm db:init` (or `npm run db:init`). The database user needs permission to create the database and tables. You can view the resulting database in HeidiSQL.
6. Create a student and a staff account:

   ```text
   pnpm account create student 20260001 "Sample Student"
   pnpm account create staff QCUSTAFF01 "Sample Staff"
   ```

   With npm, run `npm run account -- create student 20260001 "Sample Student"` and `npm run account -- create staff QCUSTAFF01 "Sample Staff"`.

   Each command prints its temporary PIN once. Share it through the school's approved process. Temporary PINs expire after 24 hours and must be changed at first sign-in. After five incorrect PIN attempts, an account is locked for 15 minutes. To reset an account, run `pnpm account reset <account-number>`.

7. Start the site with `pnpm start` (or `npm start`) and open `http://localhost:3000`.

## Deployment notes

- Serve production traffic over HTTPS. Set `NODE_ENV=production` so the session cookie uses the `Secure` attribute.
- Set `HOST=0.0.0.0` only when the app must accept traffic through a trusted production reverse proxy; local development binds to `127.0.0.1`.
- Use a restricted MariaDB account, automated database backups, and a private secret manager for `SESSION_SECRET` and `PIN_PEPPER`.
- The web server must be reachable only through the school's approved hosting and network setup.
- Staff accounts and temporary PINs are created/reset with the server-side command. Do not put real IDs or PINs in frontend JavaScript or source control.
